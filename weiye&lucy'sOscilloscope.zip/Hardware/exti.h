#ifndef __EXTI_H
#define __EXTI_H
#include "sys.h"

void EXTIX0_Init(void);//�ⲿ�жϳ�ʼ�� 
void EXTIX2_Init(void);
void EXTIX3_Init(void);
void EXTIX4_Init(void);
void EXTIX5_Init(void);

#endif

