#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Key.h"
#include "LED.h"

/**
  * 函    数：按键初始化
  * 参    数：无
  * 返 回 值：无
  */
void Key0_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//使能PORTA,PORTE时钟

    //初始化 WK_UP-->GPIOA.0	  上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //设置成上拉输入 
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA_0
}

void Key2_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//使能PORTA,PORTE时钟

    //初始化 WK_UP-->GPIOA.0	  上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_2;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //设置成上拉输入 
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA_1
}

void Key3_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//使能PORTA,PORTE时钟

    //初始化 WK_UP-->GPIOA.0	  上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_3;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //设置成上拉输入 
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA_1
}

void Key4_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//使能PORTA,PORTE时钟

    //初始化 WK_UP-->GPIOA.0	  上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //设置成上拉输入 
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA_1
}


void Key5_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//使能PORTA,PORTE时钟

    //初始化 WK_UP-->GPIOA.0	  上拉输入
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_5;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU; //设置成上拉输入 
    GPIO_Init(GPIOA, &GPIO_InitStructure);//初始化GPIOA_1
}
/**
  * 函    数：按键获取键码
  * 参    数：无
  * 返 回 值：按下按键的键码值，范围：0~2，返回0代表没有按键按下
  * 注意事项：此函数是阻塞式操作，当按键按住不放时，函数会卡住，直到按键松手
  */
uint8_t Key0_GetNum(void)
{
    uint8_t KeyNum = 0; //定义变量，默认键码值为0

    if (KEY0 == 0)  //读PB1输入寄存器的状态，如果为0，则代表按键1按下
    {
        Delay_ms(20);       //延时消抖
        while (KEY0 == 0);  //等待按键松手
        Delay_ms(20);       //延时消抖
        
        LED_Turn();         //置键码为1
    }

    return KeyNum;          //返回键码值，如果没有按键按下，所有if都不成立，则键码为默认值0
}
