#ifndef __ENCODER_H
#define __ENCODER_H

void Encoder_TIM3_Init(void);
int16_t Encoder_TIM3_Get(void);
void Encoder_TIM1_Init(void);
int16_t Encoder_TIM1_Get(void);

#endif
