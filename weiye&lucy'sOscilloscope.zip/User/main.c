#include "User.h"   
#include "PWM.h"

#define MAX_Fre_Sam 768000  //最大采集频率
#define MIN_Fre_Sam 256     //最低采集频率
#define OLED_Width  128     //屏幕的宽度
#define OLED_Height 64      //屏幕的高度
/******************************    核心变量定义区域    *************************/
//制作：伟业、lucy
//只需要256个点就最够了   分辨率最够  同时fft的计算时间也快
extern uint16_t ADCData[ADCDataLength];     //用来存放

uint16_t Index_Draw = 0;
float VOL[ADCDataLength];
complex data[ADCDataLength];
float Fre_Sam = 2560;  //单片机的初始采集频率

float MAX;      //频谱图的最大值
uint16_t index_MAX; //频谱图最大值的系数
float Fre;      //信号的频率

uint8_t SHOW = 1;
uint8_t STOP = 0;
uint8_t SPEC = 0;
uint8_t RIGHT = 2;  //初始值为2 开机的时候先进行一次波形的自动跟踪

float Point = 16; //一个波形被采集的点数
float WaveNum = 4;  //一次显示两个波形
float Stop_WaveNum = 4;  //一次显示两个波形

float VPP = 3.3, MIN_WAVE = 0;
int MIN_INDEX = 0;

uint8_t CODE_Choice = 0;

uint8_t i;	

int main(void)
{
    //初始化函数
    Init_ALL();
    float fre_sam_wave = 0; 
    while (1)
    {
		
        if(STOP == 0)
        {
            Fre = Obtain_Fre();     //此次采集只用于获取此时的信号频率
            if(RIGHT == 2)    //RIGHT设置为2是为了防止丢失
            {
                Printf(1,".....   AUTO   ..... ");
                Right_Fre();  //获取正确的频率
                Point = 16;
                fre_sam_wave = Fre * Point; //采集频率是实际频率的16左右，为了一个完整的波形可以采集16个点，可以更好的观察波形 
                if(fre_sam_wave > MAX_Fre_Sam || fre_sam_wave < MIN_Fre_Sam)  //判断下一次的频率是否合法 如果不合法说明采集已经到极限了
                {
                    if(fre_sam_wave > MAX_Fre_Sam)   //说明此时无法合法，需要调整到合法范围进行最后一次获取频率
                    {
                        fre_sam_wave = MAX_Fre_Sam;
                    }
                    if(fre_sam_wave < MIN_Fre_Sam)
                    {
                        fre_sam_wave = MIN_Fre_Sam;
                    }
                }
                Point = fre_sam_wave / Fre;    //修改Point
                RIGHT = 1;
            }
            
            //开始采集信号
            Set_SamplingFre(fre_sam_wave);      //此信号只是用来显示的，不用来表示此时的频率
            MY_Get_Vol(VOL);    //开始获取此时的信号
            
            //更新显示数据
            if(RIGHT == 1) //获取此时波形的各项参数  用于后续的打印波形
            {
                float max = 0,min = 3.3;
                for(int i = 0;i<ADCDataLength/2;i++)
                {
                    if(max < VOL[i])
                    {
                        max = VOL[i];
                    }
                    if(min > VOL[i])
                    {
                        min = VOL[i];
                        MIN_INDEX = i;
                    }
                }
                MIN_WAVE = min - 0.1;
                VPP = max - min + 0.2;
                RIGHT = 0;
            }
        }
        if(SPEC == 1)//此时展示当前的频谱图   第三个按钮
        {
            if(STOP == 1)   //用于暂停之后还可以获取信号进行显示
            {
                Set_SamplingFre(fre_sam_wave);      //此信号只是用来显示的，不用来表示此时的频率
                MY_Get_Vol(VOL);
            }
            OLED_Show_SPEC(fre_sam_wave);   //打印此时的频域图
            continue;
        }
        //此时数据已经更新完成，可以开始后续的显示和数据打印
        if(SHOW == 1) 
        {
            OLED_Show_Wave();   //显示时域图  
        }
        else
        {
            OLED_Show_Date(fre_sam_wave);   //显示此时的波形的各项参数
        }
    }
}


void Init_ALL( void )
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //设置NVIC中断分组2:2位抢占优先级，2位响应优先级
    
    LED_Init(); //蓝色小灯的初始化  用于按键的显示
    
    //我擦擦擦擦QAQ串口1被编码器占用了
    //uart_init(115200);  //串口1初始化，串口速度是115200
    uart3_init(115200);  //串口3初始化，串口速度是115200
    
    Encoder_TIM1_Init();    //编码器初始化
    
    OLED_Init();    //OLED屏幕初始化
    
    EXTIX0_Init();   //中断初始化
    EXTIX2_Init();   //中断初始化
    EXTIX3_Init();   //中断初始化
    EXTIX4_Init();   //中断初始化
    EXTIX5_Init();   //中断初始化
    
    MY_ADC_Init();  //ADC初始化
    
    Timer2_NVIC_Init();     //时钟2定时器初始化
}
//画图形的函数        //当频率低于20hz的时候显示的波形将不在稳定，因为只可以显示这么多
void OLED_Show_Wave( void )
{
    OLED_Clear();   //清理此时屏幕上的其他东西 
    float step = OLED_Width / (Point * WaveNum);
    float lastX = 0;
    float x = step;
    int begin = 0;
    
    //判断此时是否是方波  因为后续的信号处理方式不同  需要打印信号的起始位置，可以让打印的波形不抖动
    uint8_t if_Square = 0;
    for(int i = 0;i<ADCDataLength / 2;i++)
    {
        if(VOL[i] - VOL[i + 1] >= VPP * 0.5)
        {
            if_Square = 1;
            break;            
        }
    }
    
    //设置此时打印波形信号开始的位置
    if(if_Square)   //此时是方波     
    {
        for(int i = begin;i < ADCDataLength - Point * WaveNum;i++)
        {
            if(VOL[i] - VOL[i+1] < VPP * 0.1 && VOL[i + 1] - VOL[i + 2] > VPP * 0.5 && VOL[i + 2] - VOL[i + 3] < VPP * 0.1)
            {
                begin = i + 1;
            }
        }
    }
    else   //此时是三角波或者正弦波
    {
        int if_begin = 1;
        if(VOL[begin] - VOL[begin + 1] > 0)    
        {
            if_begin = 0;
        }
        for(int i = begin;i < ADCDataLength - Point * WaveNum;i++)
        {
            if(VOL[i] - VOL[i+1] < 0)
            {
                if_begin = 1;
            }
            if(VOL[i] - VOL[i+1] > 0 && VOL[i+1] - VOL[i+2] > 0 && if_begin == 1)
            {
                begin = i;
                break;
            }
        }
    }
    //获取完开始位置之后开始打印波形
    float lastY = ((VOL[begin] - MIN_WAVE) / VPP * OLED_Height);
    for(int i = begin; i < begin + OLED_Width / step && i < ADCDataLength; i++,x+=step)
    {
        OLED_DrawLine(lastX,64 - lastY,x,64 - ((VOL[i] - MIN_WAVE) / VPP * OLED_Height));
        lastX = x;
        lastY = ((VOL[i] - MIN_WAVE) / VPP * OLED_Height);
    }
    OLED_Update();  //把波形更新到屏幕上
}
//显示此时的参数
void OLED_Show_Date( float fre_sam ) 
{
    Printf(1,"Fre: %0.1lf            ",Fre);    //打印此时的频率
    float max = 0,min = 3.3,duty = 0;
    for(int i = 0;i<ADCDataLength/2;i++)
    {
        if(max < VOL[i])
        {
            max = VOL[i];
        }
        if(min > VOL[i])
        {
            min = VOL[i];
        }
    }
    Printf(2,"max: %0.3lf            ",max);
    Printf(3,"min: %0.3lf            ",min);
    Printf(4,"vpp: %0.3lf            ",max - min);
    float mid = (max - min)/2 + min;
    for(int i = 0;i<ADCDataLength/2;i++)
    {
        if(VOL[i] > mid)
        {
            duty++;
        }
    }
    Printf(5,"duty: %0.3lf                    ",duty * 2.0 / ADCDataLength);    //此时的占空比
    switch (Judge_Wave())   //判断波的类型
    {
        case 0:{
            Printf(6,"Sine                        ");   //正弦波
            break;
        }
        case 1:{
            Printf(6,"Triangular                   ");  //三角波
            break;
        }
        case 2:{
            Printf(6,"Square wave                  ");  //方波
            break;
        }
    }
    
    Printf(7,"                               ");
    Printf(8,"Fre_Sam:%0.1lf                  ",fre_sam);
    OLED_Update();
}
//展示此时的频谱图
void OLED_Show_SPEC( float fre_sam )
{
    unsigned int count = 0;
    //时域图处理  获取此时的频域图，用于后续的打印
    // 将电压数据转化为复数
    float vol[ADCDataLength];
    for (count = 0; count < ADCDataLength; count++)
    {
        vol[count] = VOL[count];
        data[count].real = vol[count];  // 实部为电压值
        data[count].imag = 0;           // 虚部为0
    }
    fft(ADCDataLength, data);
    for (count = 0; count < ADCDataLength; count++)
    {
        vol[count] = sqrt(data[count].real * data[count].real + data[count].imag * data[count].imag);//模值计算 
    }
    vol[0] = vol[0] / ADCDataLength;// 提取直流量 第一个数据除以采样点数为直流分量 
    for (count = 1; count < ADCDataLength; count++)// 提取谐波分量
    {
        vol[count] = vol[count] / ADCDataLength * 4; // 对应频点模值除以采样点数乘以4得到幅值                        
    }
    //此时信号已经处理完成可以开始准备打印
    //开始处理信号的显示
    OLED_Clear();   //清理之前屏幕上的内容
    uint16_t lastX = 1;
    uint16_t lastY = vol[1] * 10;
    Printf(1,"F=%0.0lf FS=%0.0lf",Fre,fre_sam);
    for(int i = 2; i < OLED_Width; i++)
    {
        OLED_DrawLine(lastX,lastY + 64,i,64 - vol[i] * 10);
        lastX = i;
        lastY = vol[i] * 10;
    }
    OLED_Update();  //更新屏幕的数据
}
//获取fre_sample采集频率下的频率的函数
float Obtain_Fre( void )
{
    float frequency = 0;
    unsigned int count = 0;

    Set_SamplingFre(Fre_Sam);
    MY_Get_Vol(VOL);
    // 将电压数据转化为复数
    for (count = 0; count < ADCDataLength; count++)
    {
        data[count].real = VOL[count];  // 实部为电压值
        data[count].imag = 0;           // 虚部为0
    }
    fft(ADCDataLength, data);
    for (count = 0; count < ADCDataLength; count++)
    {
        VOL[count] = sqrt(data[count].real * data[count].real + data[count].imag * data[count].imag);//模值计算 
    }
    VOL[0] = VOL[0] / ADCDataLength;// 提取直流量 第一个数据除以采样点数为直流分量 
    for (count = 1; count < ADCDataLength; count++) // 提取谐波分量
    {
        VOL[count] = VOL[count] / ADCDataLength * 4;                         
    }
    for (count = 1, MAX = 0, index_MAX = 1; count < ADCDataLength / 2; count++) //获取最大值来计算此时的频率
    {
        if (VOL[count] > MAX)
        {
            MAX = VOL[count];
            index_MAX = count;
        }
    }
    frequency = index_MAX * Fre_Sam / ADCDataLength;
    return frequency;
}

//获取正确的频率
void Right_Fre( void )
{
    WaveNum = 4;    //把WaveNum的值修改回来
    float now_frequency = 0;
    float last_frequency = 0;
    Fre_Sam = MAX_Fre_Sam / 3 * 2;  //设置采集的最大频率
    while(1)    //用了一个类似与递归的方式  但是不建议单片机使用递归  栈很容易堆满
    {
        now_frequency = Obtain_Fre();
        if(last_frequency == now_frequency) //判断上次信号的频率是否这次改变采样率之后获取的频率相同
        {
            break;
        }
        Fre_Sam = now_frequency * 2.56;     //考虑下一次的采集频率
        if(Fre_Sam > MAX_Fre_Sam || Fre_Sam < MIN_Fre_Sam)  //判断下一次的频率是否合法 如果不合法说明采集已经到极限了
        {
            if(Fre_Sam > MAX_Fre_Sam)   //说明此时无法合法，需要调整到合法范围进行最后一次获取频率
            {
                Fre_Sam = MAX_Fre_Sam;
                now_frequency = Obtain_Fre();
            }
            if(Fre_Sam < MIN_Fre_Sam)
            {
                Fre_Sam = MIN_Fre_Sam;
                now_frequency = Obtain_Fre();
            }
            break;
        }
        last_frequency = now_frequency; //把上一次循环的频率值进行更新，用于下一次比价
    }
    Fre = now_frequency;    //把频率进行更新
}

//判断波形的类型
uint8_t Judge_Wave( void )  
{
    //利用频谱图的关系进行波形的判断
    float vol_arr[ADCDataLength];
    float max = 0;
    unsigned int count,index;
    for (count = 0; count < ADCDataLength; count++)
    {
        vol_arr[count] = VOL[count];
        data[count].real = vol_arr[count]; 
        data[count].imag = 0;
    }
    fft(ADCDataLength, data);
    for (count = 0; count < ADCDataLength; count++)
    {
        vol_arr[count] = sqrt(data[count].real * data[count].real + data[count].imag * data[count].imag); 
    }
    vol_arr[0] = vol_arr[0] / ADCDataLength; 
    for (count = 1; count < ADCDataLength; count++)
    {
        vol_arr[count] = vol_arr[count] / ADCDataLength * 4;                         
    }
    for (count = 1, max = 0, index = 1; count < ADCDataLength / 2; count++)
    {
        if (vol_arr[count] > max)
        {
            max = vol_arr[count];
            index = count;
        }
    }
    if(vol_arr[index*3] > vol_arr[index] * 0.2)
    {
        return 2;
    }
    else if(vol_arr[index*3] > vol_arr[index] * 0.1)
    {
        return 1;
    }
    return 0;
}

//i 的范围是1 - 8
void Printf(int i, char *format, ... )
{
    //打印函数   方便数据的打印
    i--;
    if(i > 8)
    {
         i = 8;
    }
    char String[256];                       //定义字符数组
    va_list arg;                            //定义可变参数列表数据类型的变量arg
    va_start(arg, format);                  //从format开始，接收参数列表到arg变量
    vsprintf(String, format, arg);          //使用vsprintf打印格式化字符串和参数列表到字符数组中
    va_end(arg);                            //结束变量arg
    OLED_ShowString(0, i * 8, String, OLED_6X8);//OLED显示字符数组（字符串）
    OLED_Update(); 
}


//时钟2的定时中断
void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
    {
        int encode = Encoder_TIM1_Get();
        if(encode != 0)
        {
            switch(CODE_Choice)
            {
                case 0:{
                    WaveNum = WaveNum * (encode * 0.2 + 1);
                    if(Fre_Sam > MAX_Fre_Sam || Fre_Sam < MIN_Fre_Sam)  //判断下一次的频率是否合法 如果不合法说明采集已经到极限了
                    {
                        if(Fre_Sam > MAX_Fre_Sam)   //说明此时无法合法，需要调整到合法范围进行最后一次获取频率
                        {
                            Fre_Sam = MAX_Fre_Sam;
                        }
                        if(Fre_Sam < MIN_Fre_Sam)
                        {
                            Fre_Sam = MIN_Fre_Sam;
                        }
                    }
                    break;
                }
                case 1:{
                    VPP += encode * 0.2;
                    if(VPP < 0.1)
                    {
                        VPP = 0.1;
                    }
                    break;
                }
                case 2:{
                    MIN_WAVE -= encode * 0.2;
                    if(MIN_WAVE < -3.3)
                    {
                        MIN_WAVE = -3.3;
                    }
                    else if(MIN_WAVE > 3.3)
                    {
                        MIN_WAVE = 3.3;
                    }
                    break;
                }
            }
        }
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}


//外部中断0服务程序 
void EXTI0_IRQHandler(void) //显示方式的切换
{
    if(KEY0 == 0)          //KEY0按键
    {
        LED_Turn();
        Delay_ms(20);        //延时消抖
        while (KEY0 == 0);   //等待按键松手
        Delay_ms(20);        //延时消抖
        LED_Turn();
        if(SPEC == 1)
        {
            SPEC = 0;
        }
        else
        {
            SHOW = !SHOW; 
        }
    }
    EXTI_ClearITPendingBit(EXTI_Line0); //清除LINE0上的中断标志位  
}

//外部中断0服务程序 
void EXTI2_IRQHandler(void) //是否停止波形采集
{
    if(KEY2 == 0)          //KEY2按键
    {
        LED_Turn();
        Delay_ms(20);        //延时消抖
        while (KEY2 == 0);   //等待按键松手
        Delay_ms(20);        //延时消抖
        LED_Turn();
        STOP = !STOP;
    }
    EXTI_ClearITPendingBit(EXTI_Line2); //清除LINE0上的中断标志位  
}

//外部中断0服务程序 
void EXTI3_IRQHandler(void) //是否显示此时的频谱图
{
    if(KEY3 == 0)          //KEY3按键
    {
        LED_Turn();
        Delay_ms(20);        //延时消抖
        while (KEY3 == 0);   //等待按键松手
        Delay_ms(20);        //延时消抖
        LED_Turn();
        SPEC = !SPEC;
    }
    EXTI_ClearITPendingBit(EXTI_Line3); //清除LINE0上的中断标志位  
}

//外部中断4服务程序 
void EXTI4_IRQHandler(void)
{
    if(KEY4 == 0)          //KEY4按键
    {
        LED_Turn();
        Delay_ms(20);           //延时消抖
        while (KEY4 == 0);       //等待按键松手
        Delay_ms(20);            //延时消抖
        RIGHT = 2;              //设置为2是为了防止丢失
        STOP = 0;
        LED_Turn();
    }
    EXTI_ClearITPendingBit(EXTI_Line4); //清除LINE0上的中断标志位  
}

void EXTI9_5_IRQHandler(void)
{
    if(KEY5 == 0)          //KEY5按键
    {
        LED_Turn();
        Delay_ms(20);        //延时消抖
        while (KEY5 == 0);   //等待按键松手
        Delay_ms(20);        //延时消抖
        LED_Turn();
        CODE_Choice++;
        CODE_Choice = CODE_Choice % 3;
        switch (CODE_Choice)
        {
            case 0:{
                Printf(1,"WaveNum");
                break;
            }
            case 1:{
                Printf(1,"VPP");
                break;
            }
            case 2:{
                Printf(1,"MIN");
                break;
            }
        }
        Delay_ms(300);
    }
    EXTI_ClearITPendingBit(EXTI_Line5); //清除LINE0上的中断标志位
}
