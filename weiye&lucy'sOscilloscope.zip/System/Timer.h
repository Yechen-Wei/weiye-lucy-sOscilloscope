#ifndef __TIMER_H
#define __TIMER_H

void Timer2_NVIC_Init(void);

#endif
